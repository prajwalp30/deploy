const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');

const app = express();
const port = 3000;

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'xmkms@123',
    database: 'notedb'
});

connection.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');
});

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.render('login');
});

app.post('/auth', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    if (username && password) {
        connection.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (error, results) => {
            if (results.length > 0) {
                req.session.loggedin = true;
                req.session.user_id = results[0].id;
                req.session.username = username;
                res.redirect('/notes');
            } else {
                res.send('Incorrect Username and/or Password!');
            }
        });
    } else {
        res.send('Please enter Username and Password!');
    }
});

app.get('/notes', (req, res) => {
    if (req.session.loggedin) {
        connection.query('SELECT * FROM notes WHERE user_id = ?', [req.session.user_id], (error, results) => {
            res.render('notes', { username: req.session.username, notes: results });
        });
    } else {
        res.send('Please login to view your notes.');
    }
});

app.post('/add-note', (req, res) => {
    if (req.session.loggedin) {
        const { title, content } = req.body;
        connection.query('INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)', [req.session.user_id, title, content], (err, result) => {
            if (err) throw err;
            res.redirect('/notes');
        });
    } else {
        res.send('Please login first.');
    }
});

app.listen(port, () => {
    console.log(`App running on http://localhost:${port}`);
});
